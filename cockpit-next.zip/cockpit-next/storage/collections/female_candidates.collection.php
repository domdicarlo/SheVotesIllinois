<?php
 return array (
  'name' => 'female_candidates',
  'label' => 'Female Candidates',
  '_id' => 'female_candidates',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'name',
      'label' => '',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
    1 => 
    array (
      'name' => 'photo',
      'label' => '',
      'type' => 'image',
      'default' => '',
      'info' => 'photo should be square proportions',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
    2 => 
    array (
      'name' => 'district_number',
      'label' => '',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'website',
      'label' => '',
      'type' => 'text',
      'default' => '',
      'info' => 'Text should be a valid url for a clickable link, including http or https. Can be website, or facebook page, etc.',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
    4 => 
    array (
      'name' => 'interview_link',
      'label' => 'She Votes IL Interview link',
      'type' => 'text',
      'default' => '',
      'info' => 'If no link is available yet, simply type in here "Coming soon", case sensitive. Otherwise, insert a valid link with http or https',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
    5 => 
    array (
      'name' => 'office',
      'label' => 'Office',
      'type' => 'select',
      'default' => '',
      'info' => 'Select the office that the candidate is running for',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
        'options' => 'US House of Representatives, Illinois State Senate, Illinois House of Representatives',
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
  ),
  'sortable' => false,
  'in_menu' => false,
  '_created' => 1598846713,
  '_modified' => 1598848843,
  'color' => '',
  'acl' => 
  array (
  ),
  'sort' => 
  array (
    'column' => '_created',
    'dir' => -1,
  ),
  'rules' => 
  array (
    'create' => 
    array (
      'enabled' => false,
    ),
    'read' => 
    array (
      'enabled' => false,
    ),
    'update' => 
    array (
      'enabled' => false,
    ),
    'delete' => 
    array (
      'enabled' => false,
    ),
  ),
);