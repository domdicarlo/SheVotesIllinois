<?php
 return array (
  'name' => 'events',
  'label' => '',
  '_id' => 'events',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'title',
      'label' => '',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
    1 => 
    array (
      'name' => 'organizers',
      'label' => 'Organizers',
      'type' => 'text',
      'default' => '',
      'info' => 'Seperate each different organizer by a comma. So if you had three organizers Apple, Broccoli, and carrots, you should write "Apple, Broccoli, Carrots"',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
    2 => 
    array (
      'name' => 'cost',
      'label' => '',
      'type' => 'text',
      'default' => '',
      'info' => 'Put in what you want the cost to be listed as. Could be everything from a dollar amount like "$5.00", "Free", or "Donations accepted", etc.',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'website',
      'label' => 'website',
      'type' => 'text',
      'default' => '',
      'info' => 'Website that has info on the event. Should be a valid url. If none, leave field blank',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => false,
    ),
    4 => 
    array (
      'name' => 'venue',
      'label' => '',
      'type' => 'set',
      'default' => '',
      'info' => 'Venue name is exactly that, venue name. Venue address can be an address, "Remote" or "Online", or whatever best describes the location of the event',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
        'fields' => 
        array (
          0 => 
          array (
            'type' => 'text',
            'name' => 'venue_name',
            'label' => 'Venue name',
          ),
          1 => 
          array (
            'type' => 'text',
            'name' => 'venue_addr',
            'label' => 'Venue address',
          ),
        ),
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
    5 => 
    array (
      'name' => 'info',
      'label' => '',
      'type' => 'wysiwyg',
      'default' => '',
      'info' => 'Write a description for the event. Information placed here will be shown in nearly the same format as you type here. You can use this to add links, bolding, underlining, etc, but one thing is don\'t add images here!',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
    6 => 
    array (
      'name' => 'image',
      'label' => '',
      'type' => 'image',
      'default' => '',
      'info' => 'Not required, but add an image for the event that previews it or promotes excitement',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    7 => 
    array (
      'name' => 'date',
      'label' => '',
      'type' => 'text',
      'default' => '',
      'info' => 'Put date in MM/DD/YY format',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
    8 => 
    array (
      'name' => 'start_time',
      'label' => '',
      'type' => 'set',
      'default' => '',
      'info' => 'Put time in HH:MM format, and then simply select am or pm. If the event is all day, simply type in "all day" (case matters) in both start and end time fields',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
        'fields' => 
        array (
          0 => 
          array (
            'type' => 'text',
            'name' => 'start_time',
            'label' => 'Start time',
          ),
          1 => 
          array (
            'type' => 'select',
            'name' => 'meridiem',
            'label' => 'Meridiem',
            'options' => 
            array (
              'options' => 'am, pm',
            ),
          ),
        ),
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
    9 => 
    array (
      'name' => 'end_time',
      'label' => '',
      'type' => 'set',
      'default' => '',
      'info' => 'Put time in HH:MM format, and then simply select am or pm. If the event is all day, simply type in "all day" (case matters) in both start and end time fields',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
        'fields' => 
        array (
          0 => 
          array (
            'type' => 'text',
            'name' => 'end_time',
            'label' => 'End time',
          ),
          1 => 
          array (
            'type' => 'select',
            'name' => 'meridiem',
            'label' => 'Meridiem',
            'options' => 
            array (
              'options' => 'am, pm',
            ),
          ),
        ),
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
    10 => 
    array (
      'name' => 'info_plain_text',
      'label' => '',
      'type' => 'text',
      'default' => '',
      'info' => 'Write a description for the event, in plain text format for when it shows up as an upcoming event. Should be similar to other info field, but no links, bolding, etc.',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
  ),
  'sortable' => false,
  'in_menu' => false,
  '_created' => 1597545724,
  '_modified' => 1598836515,
  'color' => '',
  'acl' => 
  array (
  ),
  'sort' => 
  array (
    'column' => '_created',
    'dir' => -1,
  ),
  'rules' => 
  array (
    'create' => 
    array (
      'enabled' => false,
    ),
    'read' => 
    array (
      'enabled' => false,
    ),
    'update' => 
    array (
      'enabled' => false,
    ),
    'delete' => 
    array (
      'enabled' => false,
    ),
  ),
);