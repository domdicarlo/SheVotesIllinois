<?php
 return array (
  'name' => 'articles',
  'label' => 'News, Updates, Recent Events',
  '_id' => 'articles',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'title',
      'label' => '',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
    1 => 
    array (
      'name' => 'image',
      'label' => '',
      'type' => 'image',
      'default' => '',
      'info' => 'Provide an image for article. If no image, leave blank',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => false,
    ),
    2 => 
    array (
      'name' => 'link',
      'label' => '',
      'type' => 'text',
      'default' => '',
      'info' => 'Provide a valid url, with http:// or https:// to the article',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
    3 => 
    array (
      'name' => 'featured',
      'label' => '',
      'type' => 'boolean',
      'default' => '',
      'info' => 'True if this should be feautured, false if not. If more than 3 are marked as featured, then 3 will be randomly picked ',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
    4 => 
    array (
      'name' => 'date',
      'label' => '',
      'type' => 'text',
      'default' => '',
      'info' => 'Please provide a date in MM/DD/YY format for the article',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
    5 => 
    array (
      'name' => 'type',
      'label' => '',
      'type' => 'select',
      'default' => '',
      'info' => 'Either news article, a blog, or a newsletter',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
        'options' => 'News Articles, SVI Blog Posts, Newsletters',
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
      'required' => true,
    ),
  ),
  'sortable' => false,
  'in_menu' => false,
  '_created' => 1598937944,
  '_modified' => 1598940639,
  'color' => '',
  'acl' => 
  array (
  ),
  'sort' => 
  array (
    'column' => '_created',
    'dir' => -1,
  ),
  'rules' => 
  array (
    'create' => 
    array (
      'enabled' => false,
    ),
    'read' => 
    array (
      'enabled' => false,
    ),
    'update' => 
    array (
      'enabled' => false,
    ),
    'delete' => 
    array (
      'enabled' => false,
    ),
  ),
);